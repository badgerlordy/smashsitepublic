"""smashbet URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings
from django.contrib import admin
from django.urls import include, path, re_path

from django_registration.backends.activation.views import RegistrationView
from users.forms import MyCustomUserForm
from main import views
from django.contrib.auth import views as auth_views
from main.views import PasswordResetDoneView


urlpatterns = [
    re_path(r'^accounts/password_reset/$',
        auth_views.PasswordResetView.as_view(
            template_name='django_registration/password_reset_form.html'
        ),
        name='password_reset'),
    re_path(r'^accounts/password_reset/done/$',
        PasswordResetDoneView.as_view(
            template_name='django_registration/password_reset_done.html'
        ),
        name='password_reset_done'),
    path('admin_bangomundo/', admin.site.urls),
    path('', include('main.urls')),
    path('', include('profile_stats.urls')),
    path('accounts/register/',
        RegistrationView.as_view(
            form_class=MyCustomUserForm
        ),
        name='django_registration_register',
    ),
    path('accounts/', include('django_registration.backends.activation.urls')),
#   path('accounts/', include('registration.urls')),
   path('accounts/', include('django.contrib.auth.urls')),
   path('', include('overlays.urls')),
]
