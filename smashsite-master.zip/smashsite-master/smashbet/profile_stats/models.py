from django.db import models
from users.models import CustomUser
from django.conf import settings

# Create your models here.
class Profile(models.Model):
    player = models.OneToOneField(CustomUser, on_delete=models.CASCADE, primary_key=True)
    coins = models.IntegerField(default=500)
    wins = models.IntegerField(default=0)
    losses = models.IntegerField(default=0)
    avatar = models.ImageField(upload_to='media/', default='MAYRIO.png')
    high_score = models.IntegerField(default=500)

    class Meta:
       db_table = 'profile'
