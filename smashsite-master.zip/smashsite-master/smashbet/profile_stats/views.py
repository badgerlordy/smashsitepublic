from django.shortcuts import render
from django.urls import reverse_lazy
from .forms import ProfileForm
from bootstrap_modal_forms.generic import BSModalUpdateView
from .models import Profile
from users.models import CustomUser
from django.shortcuts import render
from django.http import HttpResponse
import re
# Create your views here.

def profile(request):
    username = re.match('/profiles/([A-Za-z0-9@.+-_]+)/', request.path).group(1).lower()
    try:
        user = CustomUser.objects.get(username__iexact=username)
        username = user.username
        profile = user.profile
        return render(request, 'main/profile.html', {'username': username, 'profile': profile})
    except CustomUser.DoesNotExist:
        return render(request, 'main/invalid_profile.html', {})


def profiles(request):
    return HttpResponse('Page coming soon.')

class EditProfileView(BSModalUpdateView):
    template_name = 'main/edit_profile.html'
    form_class = ProfileForm
    success_message = 'Success: Profile was saved.'
    success_url = reverse_lazy('profile')
