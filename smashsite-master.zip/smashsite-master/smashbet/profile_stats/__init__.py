default_app_config = 'profile_stats.apps.ProfileStatsConfig'
