from django.apps import AppConfig


class ProfileStatsConfig(AppConfig):
    name = 'profile_stats'

    def ready(self):
        import profile_stats.signals
