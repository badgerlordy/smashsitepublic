from django.urls import path, re_path
from . import views
from django.views.generic.base import TemplateView
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings


urlpatterns = [
    path('', TemplateView.as_view(template_name='main/index.html'), name='index'),
    re_path(r'^profiles/$', TemplateView.as_view(template_name='main/profiles.html'), name='profiles'),
    re_path(r'^profiles/[A-Za-z0-9@.+-_]+/$', views.profile, name='profile'),
    re_path(r'^profiles/[A-Za-z0-9@.+-_]+/edit/$', views.EditProfileView, name='edit_profile'),
]
