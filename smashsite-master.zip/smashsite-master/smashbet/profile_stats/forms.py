from .models import Profile
from bootstrap_modal_forms.forms import BSModalForm

class ProfileForm(BSModalForm):
    class Meta:
        model = Profile
        fields = ['avatar']
