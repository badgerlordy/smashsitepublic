from   .models import Match, Player, BetPool
from   asgiref.sync import async_to_sync
import channels.layers
from   copy import copy
from   datetime import datetime
from   decouple import config
from   django.db.models.signals import post_save
from   django.dispatch import receiver


def get_cleaned(instance, created):
    data = copy(instance.__dict__)
    data['new'] = created
    if '_state' in data:
        del data['_state']
    return data


def send_info(data):
    channel_layer = channels.layers.get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        'main',
        {
            'type': 'info',
            'data_wrapper': {
                'CHANNEL_KEY': config('CHANNEL_KEY'),
                'data': data
            }
        }
    )


@receiver(post_save, sender=Match)
def match_info(sender, instance, created, **kwargs):
    data = get_cleaned(instance, created)
    data['type'] = 'match'
    for attr in data:
        if isinstance(data[attr], datetime):
            data[attr] = int(data[attr].timestamp())
    if data['winning_team']:
        pool = BetPool.objects.get(match=instance.id, team=data['winning_team'])
        
    # send_info(data)


@receiver(post_save, sender=Player)
def player_info(sender, instance, created, **kwargs):
    data = get_cleaned(instance, created)
    data['type'] = 'player'
    # send_info(data)
