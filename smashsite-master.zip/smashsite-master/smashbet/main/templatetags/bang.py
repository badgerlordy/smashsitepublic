from   datetime import datetime
from   django.utils.safestring import mark_safe
from   django.template import Library
import json


register = Library()


def clean_obj(obj):
    if '_state' in obj:
        obj.pop('_state')
    for key in obj.keys():
        if isinstance(obj[key], datetime):
            obj[key] = obj[key].timestamp()
    return obj


@register.filter(is_safe=True)
def js(item):
    if isinstance(item, (list, tuple)):
        for obj in item:
            obj = clean_obj(obj)
    elif isinstance(item, (str, int)):
        pass
    else:
        item = clean_obj(item)
    return mark_safe(json.dumps(item))


@register.filter
def join_names(name1, name2):
    return ' & '.join((name1, name2))
