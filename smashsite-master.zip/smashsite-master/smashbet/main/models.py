from django.db import models
from profile_stats.models import Profile
from users.models import CustomUser
from datetime import datetime, timezone

# Create your models here.

class Match(models.Model):
    bets_opened_at = models.DateTimeField(
        default=datetime(1970, 1, 1).replace(tzinfo=timezone.utc),
        blank=True
    )
    bets_open = models.BooleanField(default=True, blank=True)
    start_time = models.DateTimeField(
        default=datetime(1970, 1, 1).replace(tzinfo=timezone.utc),
        blank=True
    )
    end_time = models.DateTimeField(
        default=datetime(1970, 1, 1).replace(tzinfo=timezone.utc),
        blank=True
    )
    map = models.TextField(default='', blank=True)
    game_mode = models.TextField(default='', blank=True)
    team_mode = models.BooleanField(default=False, blank=True)
    cancelled = models.BooleanField(default=False, blank=True)
    winning_team = models.TextField(default='', blank=True)
    player_count = models.IntegerField(default=0, blank=True)
    reader_mode = models.IntegerField(default=0, blank=True)

    class Meta:
        db_table = 'match'


class Player(models.Model):
    match = models.ForeignKey(Match, on_delete=models.DO_NOTHING)
    character_name = models.TextField(default='', blank=True)
    color = models.TextField(default='', blank=True)
    color_fixed = models.TextField(default='', blank=True)
    number = models.IntegerField(default=0, blank=True)
    gsp = models.IntegerField(default=0, blank=True)

    class Meta:
        db_table = 'player'


class BetPool(models.Model):
    match = models.ForeignKey(Match, on_delete=models.DO_NOTHING)
    team = models.TextField(default='', blank=True)
    total = models.IntegerField(default=0, blank=True)

    class Meta:
        db_table = 'betpool'


class UserBet(models.Model):
    user = models.ForeignKey(Profile, on_delete=models.DO_NOTHING)
    match = models.ForeignKey(Match, on_delete=models.DO_NOTHING)
    pool = models.ForeignKey(BetPool, on_delete=models.DO_NOTHING)
    bet_amount = models.IntegerField(default=0)
    payout = models.IntegerField(default=0, blank=True)
    bet_team = models.TextField(default='')

    class Meta:
        db_table = 'user_bet'
