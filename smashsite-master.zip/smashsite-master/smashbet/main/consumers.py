from   channels.generic.websocket import AsyncWebsocketConsumer
import channels.layers
from   decouple import config
import json
import os


class InfoConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        print(self.scope)
        await self.channel_layer.group_add('main', self.channel_name)
        await self.accept()
        print('sending')
        await self.channel_layer.group_send(
            'main',
            {
                'type': 'info',

                'message': self.channel_layer.receive_count
            }
        )


    async def disconnect(self, close_code):
        await self.channel_layer.group_send(
            'main',
            {
                'type': 'info',
                'message': self.channel_layer.receive_count - 1
            }
        )
        await self.channel_layer.group_discard('main', self.channel_name)


    # message from client, not used
    async def receive(self, text_data):
        data = json.loads(text_data)


    # send info from reader to clients
    async def info(self, event):
        print('E', event)
        if 'data_wrapper' in event:
            data_wrapper = event['data_wrapper']
            if 'CHANNEL_KEY' in data_wrapper:
                if data_wrapper['CHANNEL_KEY'] == config('CHANNEL_KEY'):
                    if 'data' in data_wrapper:
                        data = data_wrapper['data']
            await self.send(text_data=json.dumps({
                'data': data
            }))
        if 'message' in event:
            await self.send(text_data=json.dumps({
                'data': {
                    'connected': event['message']
                }
            }))
