from django.contrib import admin
from .models import Match, Player, BetPool, UserBet

# Register your models here.

admin.site.register(Player)
admin.site.register(Match)
admin.site.register(BetPool)
admin.site.register(UserBet)
