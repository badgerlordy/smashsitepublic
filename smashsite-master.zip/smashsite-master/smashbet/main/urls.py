from django.urls import path, re_path
from . import views
from django.views.generic.base import TemplateView


try:
    urlpatterns = [
        path('', views.index, name='index'),
        re_path(r'^reader_post/$', views.reader_post, name='reader_post'),
        re_path(r'^place_bet/$', views.place_bet, name='place_bet'),
        re_path(r'^send_command/$', views.send_command, name='send_command')
    ]
except:
    urlpatterns = []
