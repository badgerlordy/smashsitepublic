from   .models import Profile, Match, Player, BetPool, UserBet
from   asgiref.sync import async_to_sync
import channels.layers
import copy
from   datetime import datetime
from   decouple import config
from   django.core import serializers
from   django.db.models import F
from   django.http import HttpResponse, JsonResponse
from   django.shortcuts import render
from   django.utils.translation import ugettext_lazy as _
from   django.views.decorators.csrf import csrf_protect
from   django.views.generic.base import TemplateView
import json
import logging
import math
import os
import re
from   rest_framework import status
from   rest_framework.authentication import SessionAuthentication, BasicAuthentication
from   rest_framework.decorators import api_view, authentication_classes, permission_classes
from   rest_framework.permissions import IsAuthenticated
from   rest_framework.response import Response
from   rest_framework.views import APIView
from   users.models import CustomUser


logger = logging.getLogger(__name__)


def index(request):
    COLORS = ['RED', 'BLUE', 'YELLOW', 'GREEN']
    context = {
        'now': datetime.now().timestamp(),
        'twitch_channel': config('TWITCH_CHANNEL'),
        'leaders': []
    }
    context['leaders'] = CustomUser.objects.get_leaders()
    match = {}
    try:
        match = Match.objects.latest(field_name='id')
        context['match'] = match.__dict__
        try:
            players = Player.objects.filter(match=match.id)
            context['players'] = [p.__dict__ for p in players]
            if match.team_mode:
                teams = [{'color': COLORS[i], 'names': [], 'gsp': 0} for i in range(2)]
                for player in players:
                    team = teams[COLORS.index(player.color)]
                    team['names'].append(player.character_name)
                    team['gsp'] += player.gsp
                context['teams'] = teams
        except Player.DoesNotExist:
            pass
        if not str(request.user) == 'AnonymousUser':
            try:
                bet = UserBet.objects.get(match=match.id, user=request.user.profile)
                context['bet'] = bet.__dict__
            except UserBet.DoesNotExist:
                pass
    except Match.DoesNotExist:
        pass
    context['staff'] = ['badgerlord', 'jengus']
    return render(request, 'main/index.html', context)



############################# PROCESS READER INFO ###########################


@api_view(['POST'])
def reader_post(request):
    try:
        data = json.loads(request.body.decode('utf-8'))
        if key_is_valid(data):
            data = data['data']
            game = data['game']
            game['teams'] = []
            if 'team_mode' in game and game['team_mode'] and 'players' in game:
                game['teams'] = simplify_teams(game)
            send_info(data)
            game.pop('teams')
            reader_mode = data['mode']
            if reader_mode == 1:
                create_objects(game)
            else:
                update_objects(game, reader_mode)
        return Response('Not cool')
    except ValueError as e:
        return Response(e.args[0], status.HTTP_400_BAD_REQUEST)


def simplify_teams(game):
    COLORS = ['RED', 'BLUE']
    teams = [{'names': [], 'gsp': 0, 'color': COLORS[i]} for i in range(2)]
    for player in game['players']:
        team = teams[COLORS.index(player['color'])]
        team['names'].append(player['character_name'])
        team['gsp'] += player['gsp']
    return teams


# CARD SCREEN
def create_objects(game):
    players = game.pop('players')
    game['player_count'] = len(players)
    game['bets_opened_at'] = datetime.now()
    game['cancelled'] = True if game['cancelled'] else False
    match = Match.objects.create(**game)
    colors = []
    for player in players:
        if player['color'] not in colors:
            colors.append(player['color'])
        player['color_fixed'] = player['color']
        match.player_set.create(**player)
    for color in colors:
        match.betpool_set.create(team=color)


# PREGAME SCREEN
def update_players(game, db_players):
    players = []
    if 'players' in game:
        players = game.pop('players')
        players = {p['character_name']:p for p in players}
    if players:
        for _player in db_players:
            _player.color_fixed = players[_player.character_name]['color']
            _player.save()


def update_objects(game, reader_mode):
    match = Match.objects.latest(field_name='id')
    db_players = Player.objects.filter(match=match.id)
    if reader_mode == 2:
        update_players(game, db_players)
    if reader_mode == 3:
        game['start_time'] = datetime.now()
    if reader_mode == 4:
        game['end_time'] = datetime.now()
    if reader_mode == 5:
        winner = game['winning_team']
        if not match.team_mode:
            player = Player.objects.get(match=match.id, color_fixed=winner)
            winner = player.color
        bets = match.userbet_set.all()
        for bet in bets:
            if bet.bet_team == winner:
                amount = bet.user.coins + bet.bet_amount
                if amount > bet.user.high_score:
                    bet.user.high_score = amount
                bet.user.coins = F('coins') + bet.bet_amount
                bet.user.wins = F('wins') + 1
            else:
                if bet.user.coins - bet.bet_amount < 500:
                    bet.user.coins = 500
                else:
                    bet.user.coins = F('coins') - bet.bet_amount
                bet.user.losses = F('losses') + 1
            bet.user.save()
        leaders = CustomUser.objects.get_leaders()
        send_info({'leaders': leaders})
    custupdate(match, game)


def custupdate(obj, data):
    for k, v in data.items():
        setattr(obj, k, v)
    obj.save()


#################################### BETTING ##################################


@api_view(['POST'])
@authentication_classes((SessionAuthentication, BasicAuthentication))
@permission_classes((IsAuthenticated,))
@csrf_protect
def place_bet(request):
    print('DATA', request.data)
    try:
        data = dict(request.data.lists())
        colors = ['RED', 'BLUE', 'YELLOW', 'GREEN']
        bet_color = data['choice'][0]
        if bet_color not in colors:
            return HttpResponse('Invalid bet choice', content_type='text/plain')
        try:
            bet_amount = int(data['amount'][0])
        except ValueError:
            return HttpResponse('Invalid bet amount', content_type='text/plain')
        print(bet_amount, bet_color)
        user = request.user
        match = Match.objects.latest(field_name='id')
        bet_pool = BetPool.objects.get(match=match.id, team=bet_color)
        try:
            bet = UserBet.objects.get(match=match.id, user=user.profile)
            return HttpResponse('Bet already submitted', content_type='text/plain')
        except UserBet.DoesNotExist:
            if match.cancelled:
                return HttpResponse('Game cancelled', content_type='text/plain')
            elif not match.bets_open:
                return HttpResponse('Betting closed for this match', content_type='text/plain')
            else:
                now = datetime.now().timestamp()
                elapsed = now - match.bets_opened_at.timestamp()
                if elapsed >= 33:
                    match.bets_open = False
                    match.save()
                    return HttpResponse('Betting closed for this match', content_type='text/plain')
                else:
                    if bet_amount > user.profile.coins:
                        bet_amount = user.profile.coins
                    bet = UserBet.objects.create(
                        user=user.profile, match=match, pool=bet_pool,
                        bet_team=bet_color, bet_amount=bet_amount
                    )
                    bet.save()
                    bet_pool.total = F('total') + bet.bet_amount
                    bet_pool.save()
                    return HttpResponse('Bet submitted', content_type='text/plain')
    except Exception as e:
        print('Bet not submitted - ', e)
        return HttpResponse('Submit failed', content_type='text/plain')
    return HttpResponse('You should leave', content_type='text/plain')



#################################### MISC ##################################


@api_view(['POST'])
@authentication_classes((SessionAuthentication, BasicAuthentication))
@permission_classes((IsAuthenticated,))
@csrf_protect
def send_command(request):
    if request.user.username in ['badgerlord', 'jengus']:
        try:
            data = dict(request.data.lists())
            btn = data['button'][0]
            print(btn)
            os.system(f'PIGPIO_ADDR=raspberrypi.local python3 /home/badgerlord/Desktop/{btn}.py')
        except:
            pass
    return HttpResponse('Cool', content_type='text/plain')



def send_info(data):
    channel_layer = channels.layers.get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        'main',
        {
            'type': 'info',
            'data_wrapper': {
                'CHANNEL_KEY': config('CHANNEL_KEY'),
                'data': data
            }
        }
    )


def key_is_valid(data):
    if 'API_KEY' in data:
        if data['API_KEY'] == config('API_KEY'):
            return True
    return False


class PasswordResetDoneView(TemplateView):
    template_name = 'django_registration/password_reset_done.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return context
