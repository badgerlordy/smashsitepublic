'use strict';

const colors = ['RED', 'BLUE', 'YELLOW', 'GREEN'];
const timer_default = 30;
var timer_init = timer_default;
let remaining = 0;
var wait_for_next = false;
var initial = (new Date().getTime());
let timer = null;



// M A I N

function start() {
  start_socket();
  var loaded = (new Date()).getTime();
  if ('players' in _game) _game.players.sort((a, b) => (colors.indexOf(a.color_fixed) > colors.indexOf(b.color_fixed)));
  if (Object.keys(_game).length) {
    let now = (new Date()).getTime();
    let elapsed = now - (_game.bets_opened_at * 1000);
    let duration = timer_default * 1000;
    timer_init = parseInt((duration - elapsed) / 1000);
    if (elapsed < duration && timer_init > 3) funcs[1](_game, true);
    else if ([1, 2, 3, 4].indexOf(_game.reader_mode) >= 0) {
      $('#map-name').html(_game.map);
      $('#game-mode').html(_game.game_mode);
      if (_game.team_mode) build_team_btns(_game, true);
      else rebuild_ffa_buttons(_game);
    }
    else if (_game.reader_mode == 5) show_info('_', '_', true);
  }
}


function start_timer(load) {
  if (timer) clearInterval(timer);
  let started = (new Date()).getTime();
  if (load) {
    let load_delta = started - initial;
    started -= load_delta;
  }
  const timer_div = document.querySelector('#timer');
  $(timer_div).removeClass('invisible');
  timer_div.innerHTML = timer_init;
  toggle_betting(false);
  timer = setInterval(function() {
    let delta = Math.floor(((new Date()).getTime() - started) / 1000);
    remaining = timer_init - delta;
    if (remaining > 0) timer_div.innerHTML = remaining;
    else {
      $(timer_div).addClass('invisible');
      timer_div.innerHTML = timer_default;
      clearInterval(timer);
      timer = null;
      if (parseInt($(amount).val())) {
        if (amount.checkValidity()) {
          if (colors.indexOf(choice.value) >= 0) submit_bet();
          else show_message('No bet option selected');
        }
        else show_message('Invalid amount entered');
      }
      else show_message('No amount entered');
      amount.disabled = true;
      toggle_betting();
    }
  }, 1000);
}


var funcs = [
  // 0
  () => {},

  // 1
  (game, load=false) => {
    if (!load) timer_init = timer_default;
    wait_for_next = false;
    let disabled = false;
    if ('bets_open' in _game && !_game.bets_open) disabled = true;
    if (game.cancelled) {
      disabled = true;
      $('#bet-overlay').removeClass('invisible');
      return null;
    }
    $('#team-btns').empty();
    choice.value = '';
    amount.value = '';
    if (game.team_mode) build_team_btns(game, disabled);
    else build_ffa_buttons(game, disabled);
    _game = game;
    start_timer(load);
    show_info(game.map, game.game_mode);
  },

  // 2
  game => {
    let waited = 0;
    let wait = setInterval(function() {
      if (remaining <= 0 || waited >= timer_default) {
        clearInterval(wait);
        if (game.team_mode) build_team_btns(game, true);
        else rebuild_ffa_buttons(game, true);
      }
      waited++;
    }, 1000);
  },

  // 3
  game => {
    _game.bets_open = false;
  },

  // 4
  () => {},

  // 5
  update_winner
];


// C O N S T R U C T I O N

function build_bet_button(html, color, col_w, disabled=false) {
  let btn = document.createElement('button');
  btn.disabled = disabled;
  let div = document.createElement('div');
  div.className = 'bet-btn-div col-lg-' + col_w;
  btn.className = color + '-team-btn btn bet-btn col-12';
  btn.addEventListener('click', function() {select(this.value)});
  $(btn).attr({'value': color, 'type': 'button'});
  $(btn).html(html);
  $('#team-btns').append(div);
  $(div).append(btn);
}


function build_team_btns(game, disabled=false) {
  for (const team of game.teams) {
    let html = '<span class="character-name">' + team.names.join(' & ') + '</span><br>GSP: ' + Number(team.gsp).toLocaleString();
    build_bet_button(html, team.color, 6, disabled);
  }
  if (quick_validate()) select($(choice).val());
}


function build_ffa_buttons(game, disabled=false, func=player=>{}, sort=true) {
  if (sort) game.players.sort((a, b) => (colors.indexOf(a.color) - colors.indexOf(b.color)));
  const len = game.players.length;
  const col_w = 12 / len;
  for (const player of game.players) {
    let color = player.color;
    if ('color_fixed' in player) color = player.color_fixed
    let html = `<span class="character-name">${player.character_name}</span><br>GSP: ${Number(player.gsp).toLocaleString()}`;
    build_bet_button(html, color, col_w, disabled);
    func(player);
  }
}


function rebuild_ffa_buttons(game, disabled=true) {
  _game.colors_changed = game.colors_changed;
  if ('players' in game) {
    $('#team-btns').empty();
    build_ffa_buttons(game, disabled, player => {
      let _player = _game.players.filter(p => (p.character_name === player.character_name))[0];
      if (!('color_fixed' in _player)) _player.color_fixed = player.color;
    }, false);
  }
  else for (let _player of _game.players) _player.color_fixed = _player.color;
  if (quick_validate()) {
    let player = _game.players.filter(p => (p.color === choice.value))[0];
    select(player.color_fixed);
  }
}



// D I S P L A Y

function update_leaders(data) {
  let table = document.getElementById('leaderboard');
  let tbody = table.getElementsByTagName('tbody')[0];
  tbody.innerHTML = '';
  for (let i = 0; i < data.leaders.length; i++) {
    let leader = data.leaders[i];
    let tr = document.createElement('tr');
    if (leader.name === username) $(tr).addClass('bg-light');
    let th = document.createElement('th');
    th.setAttribute('scope', 'row');
    th.innerHTML = i + 1;
    tr.appendChild(th);
    let name = document.createElement('td');
    name.innerHTML = `<a href="/profiles/${leader.name}">${leader.name}</a>`;
    tr.appendChild(name);
    let coins = document.createElement('td');
    coins.innerHTML = Number(leader.coins).toLocaleString() + ' b&cent;';
    tr.appendChild(coins);
    tbody.appendChild(tr);
  }
}


function update_winner(game) {
  let winner = game['winning_team'];
  let player = _game.players.filter(p => (p.color_fixed === winner))[0];
  winner = player.color_fixed;
  if (quick_validate()) {
    let amt = parseInt($(amount).val());
    if ($(choice).val() === winner) {
      show_message('You won (' + amt + ' b&cent;)!')
      coin_total += amt;
    }
    else {
      coin_total -= amt;
      show_message('You lost (' + amt + ' b&cent;)')
      if (coin_total < 500) {
        show_message(`(${amt} b&cent;) lost, amount reset to (500)`)
        coin_total = 500;
      }
    }
    $('.coins').html(Number(coin_total).toLocaleString());
    $(amount).attr('max', coin_total);
  }
  setTimeout(() => {
    choice.value = '';
    amount.value = '';
    toggle_overlay();
    show_info('_', '_', true);
  }, 16000);
}


function toggle_overlay(msg=null) {
  let overlay = $('#bet-overlay');
  if (msg) {
    if (msg === 'ffa') msg = 'FFA games with duplicate characters are currently unsupported.';
    $(overlay).removeClass('invisible');
    $(overlay).html(msg);
  }
  else $(overlay).addClass('invisible');
}

function show_info(map='', game_mode='', clear=false) {
  let waiting = '*** waiting for next match ***';
  if (map === '_') {
    map = waiting;
    show_message(waiting);
  }
  if (game_mode === '_') game_mode = waiting;
  if (clear) $('#team-btns').empty();
  if (map) $('#map-name').html(map);
  if (game_mode) $('#game-mode').html(game_mode);
}


function toggle_betting(disable=true) {
  $('.bet-btn').prop('disabled', disable);
  $('.inc-btn').css('pointer-events', disable ? 'none': 'auto');
  amount.disabled = disable;
  if (!disable) {
    show_message('Place your bet!');
    choice.value = '';
    amount.value = '';
    let msg = 'Enter bet amount';
    amount.setAttribute('placeholder', msg);
    amount.setAttribute('aria-label', msg);
  }
  else {
    let msg = 'Betting closed for this match';
    amount.setAttribute('placeholder', msg);
    amount.setAttribute('aria-label', msg);
  }
}


function select(color) {
  $('#bet-choice').val(color);
  let btns = document.querySelectorAll('.bet-btn');
  for (let btn of btns) {
    let parent = btn.parentNode;
    let class_name = btn.value + '-selected';
    if (btn.value === color) $(btn.parentNode).addClass(class_name);
    else $(parent).removeClass(class_name);
  }
}



// S O C K E T

var reconnect_timer_alert = null;

function start_socket() {
  let loc = window.location;
  var wsStart = 'ws://';
  if (loc.protocol == 'https:') {
    wsStart = 'wss://';
  }
  var endpoint = wsStart + loc.host + loc.pathname + 'ws';
  var socket = new WebSocket(endpoint);

  socket.onmessage = socket_message;

  socket.onopen = socket_open;

  socket.onerror = function(e) {
    console.log('error', e);
  };
  socket.onclose = function(e) {
    setTimeout(start_socket, 3000);
    reconnect_timer_alert = setTimeout(function() {
      toggle_overlay('Connection to server lost, attempting to reconnect.');
      show_info('', '');
    }, 7000);
  };
}


function socket_message(e) {
  let data = JSON.parse(e.data).data;
  if ('game' in data) show_game(data);
  if ('leaders' in data) update_leaders(data);
  if ('connected' in data) $('#info_c').html(data.connected);
}


function show_game(data) {
  let game = data.game;

  if (logged_in) {
    if (game.cancelled) {
      toggle_overlay('ffa');
      show_info('', '', true);
      wait_for_next = true;
    }
    else {
      if (wait_for_next && data.mode !== 1) return null;
      toggle_overlay();
      funcs[data.mode](game);
    }
  }
}


function socket_open(e) {
  console.log('open');
  if (logged_in) {
    if (_game.cancelled) toggle_overlay('ffa');
    else toggle_overlay();
  }
  else toggle_overlay('<a href="/accounts/login">Login</a> or <a href="/accounts/register">register</a> now to bet for free!');
  show_info();
  if (reconnect_timer_alert) {
    clearInterval(reconnect_timer_alert);
    reconnect_timer_alert = null;
  }
}


// A J A X

var csrftoken = null;
function submit_bet() {
  let bet_choice = $(choice).val();
  if ('colors_changed' in _game && _game['colors_changed']) {
    let player = _game.players.filter(p => (p.color_fixed === bet_choice))[0];
    bet_choice = player.color;
  }
  var bet_data = {
    choice: bet_choice,
    amount: $(amount).val()
  };

  $.ajax({
    beforeSend: function(xhr, settings) {
      if (!csrftoken) csrftoken = getCookie('csrftoken');
      if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
        xhr.setRequestHeader('X-CSRFToken', csrftoken);
      }
    },
    url: window.location.href.split('#')[0] + 'place_bet/',
    method: 'POST',
    data: bet_data,
    success: msg => show_message(msg),
    dataType: 'text'
  });
}


// M I S C E L L A N E O U S

function dismiss() {
  document.cookie = 'dismissed=true;'
}


function getCookie(name) {
  var cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
      var cookie = $.trim(cookies[i]);
      if (cookie.substring(0, name.length + 1) === (name + '=')) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}


function csrfSafeMethod(method) {
  return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
}


function add_amount(el) {
  let perc = parseInt(el.innerHTML) / 100;
  let amt = Math.ceil(coin_total * perc);
  let bet = 0;
  if (quick_validate(false, true)) bet = parseInt($(amount).val());
  bet += amt;
  if (bet > coin_total) bet = coin_total;
  $(amount).val(bet);
}


function quick_validate(skip_amount=false, skip_choice=false) {
  return (
    ((parseInt($(amount).val()) && amount.checkValidity()) || skip_amount) &&
    (colors.indexOf(choice.value) >= 0 || skip_choice)
  );
}


// T W I T C H

let navbar = document.querySelector('.navbar')
let player = document.getElementById('twitch-embed');
let chat = document.getElementById('chat-iframe');

function fix_sizes() {
  let nav_height = navbar.offsetHeight;
  let upper_height = (window.innerHeight - 225 - nav_height);
  let el_height = upper_height * .90
  chat.style.height = el_height + 'px';
  player.style.maxHeight = el_height + 'px';
  player.style.height = el_height + 'px';
  if (window.innerHeight > window.innerWidth) {
    $('#leaderboard-btn').removeClass('d-none');
    $('#leaderboard-heading').addClass('d-none');
    $('#leaderboard-div').removeClass('show');
  }
  else {
    $('#leaderboard-btn').addClass('d-none');
    $('#leaderboard-heading').removeClass('d-none');
    $('#leaderboard-div').addClass('show');
  }
  //upper.style.maxHeight = el_height + 'px';
}


function twitch() {

  var options = {
    width: 1152,
    height: 648,
    channel: channel,
  };
  var player = new Twitch.Player("twitch-embed", options);
  player.setVolume(0.5);
  $('#twitch-embed iframe').css({'width': '100%', 'height': '100%', 'min-height': '360px'});
  $('#chat-embed iframe').css({'width': '100%', 'min-height': '360px'});
  fix_sizes();
}



// W H A T A R E Y O U L O O K I N G A T

$(document).ready(function() {
  let btn = document.querySelector('#leaderboard-btn');
  $(btn).removeClass('invisible');
  if (window.innerWidth > window.innerHeight) btn.click();
  twitch();
});

if (!getCookie('dismissed')) {
  document.getElementById('status-alert').classList.remove('d-none');
}

window.onresize = fix_sizes;
start();
