var loc = window.location;

function start_socket() {
  var wsStart = 'ws://';
  if (loc.protocol == 'https:') {
    wsStart = 'wss://';
  }
  var endpoint = wsStart + loc.host + '/' + 'ws';
  var socket = new WebSocket(endpoint);

  socket.onmessage = socket_message;

  socket.onerror = function(e) {
    console.log('error', e);
  };
  socket.onclose = function(e) {
    setTimeout(start_socket, 3000);
    reconnect_timer_alert = setTimeout(function() {
      toggle_overlay('Connection to server lost, attempting to reconnect.');
      show_info('', '');
    }, 7000);
  };
}

start_socket();
	
function socket_message(e) {
  let data = JSON.parse(e.data).data;
  if ('leaders' in data) show_leaders(data);
}

function show_leaders(data) {
  let table = document.getElementById('leaderboard');
  let tbody = table.getElementsByTagName('tbody')[0];
  tbody.innerHTML = '';
  for (let i = 0; i < data.leaders.length; i++) {
    let leader = data.leaders[i];
    let tr = document.createElement('tr');
    let th = document.createElement('th');
    th.setAttribute('scope', 'row');
    th.innerHTML = i + 1;
    tr.appendChild(th);
    let name = document.createElement('td');
    name.innerHTML = `<a href="/profiles/${leader.name}">${leader.name}</a>`;
    tr.appendChild(name);
    let coins = document.createElement('td');
    coins.innerHTML = Number(leader.coins).toLocaleString();
    tr.appendChild(coins);
    tbody.appendChild(tr);
  }
}
