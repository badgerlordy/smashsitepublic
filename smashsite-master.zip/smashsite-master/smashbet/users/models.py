from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager

# Create your models here.

class CustomerUserManager(UserManager):
    def get_by_natural_key(self, username):
        case_insensitive_username_field = '{}__iexact'.format(self.model.USERNAME_FIELD)
        return self.get(**{case_insensitive_username_field: username})


    def get_leaders(self, num=5):
        users = CustomUser.objects.raw('SELECT player_id AS id FROM profile ORDER BY coins DESC limit ' + str(num))
        data = [{'name': u.username, 'coins': u.profile.coins} for u in users]
        return data


class CustomUser(AbstractUser):
    objects = CustomerUserManager()

    def __str__(self):
        return self.email
