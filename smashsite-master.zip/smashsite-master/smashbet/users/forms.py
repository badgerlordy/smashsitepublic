from django import forms

from captcha.fields import ReCaptchaField

from django_registration.forms import RegistrationFormUniqueEmail, RegistrationFormCaseInsensitive
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import CustomUser
from django.utils.translation import ugettext_lazy as _
from django.core.exceptions import ValidationError

import os

bad_names = []
filename = 'bad_names.txt'
if os.path.isfile(filename):
    with open(filename, 'r') as infile:
        bad_names = infile.read().splitlines()


class MyCustomUserForm(RegistrationFormUniqueEmail, RegistrationFormCaseInsensitive):
    class Meta(RegistrationFormUniqueEmail.Meta):
        model = CustomUser
        fields = ('username', 'email', 'password1', 'password2')
        captcha = ReCaptchaField()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for visible in self.visible_fields():
            if visible.name == 'username':
                visible.help_text = 'Required. 20 characters or fewer. Letters, digits and @/./+/-/_ only.'
            visible.field.widget.attrs['class'] = 'form-control'


    def clean_username(self):
        cleaned = super().clean()
        username = cleaned.get('username')
        if len(username) > 20:
            raise ValidationError('Username must be 20 characters or less')
        if username.lower() in bad_names:
            raise ValidationError('Username not allowed')
        return username


class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm):
        model = CustomUser
        fields = ('username', 'email')


class CustomUserChangeForm(UserChangeForm):
    class Meta:
        model = CustomUser
        fields = ('username', 'email')
