from django.apps import AppConfig


class OverlaysConfig(AppConfig):
    name = 'overlays'
