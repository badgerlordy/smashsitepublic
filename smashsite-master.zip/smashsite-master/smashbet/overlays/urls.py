from django.urls import path, re_path
from . import views
from django.views.generic.base import TemplateView
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings


urlpatterns = [
    path('syegdfgs&748FGgeuKil/', TemplateView.as_view(template_name='overlays/leaderboard.html'), name='leaderboard'),
]
