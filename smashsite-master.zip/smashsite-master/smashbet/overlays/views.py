from   asgiref.sync import async_to_sync
import channels.layers
import copy
from   datetime import datetime
from   decouple import config
from   django.core import serializers
from   django.db.models import F
from   django.http import HttpResponse, JsonResponse
from   django.shortcuts import render
from   django.utils.translation import ugettext_lazy as _
from   django.views.decorators.csrf import csrf_protect
from   django.views.generic.base import TemplateView
import json
import logging
import math
import os
import re
from   rest_framework import status
from   rest_framework.authentication import SessionAuthentication, BasicAuthentication
from   rest_framework.decorators import api_view, authentication_classes, permission_classes
from   rest_framework.permissions import IsAuthenticated
from   rest_framework.response import Response
from   rest_framework.views import APIView
from   users.models import CustomUser
from   main.views import send_info, key_is_valid


logger = logging.getLogger(__name__)


def leaderboard(request):
    context = {
        'leaders': []
    }
    context['leaders'] = CustomUser.objects.get_leaders()

    print(context)
    return render(request, 'overlays/leaderboard.html', context)
